
public class BSTNode {
	
	public int data;
	public BSTNode leftChild;
	public BSTNode rightChild;
	
	public BSTNode(int data) {
		this.data = data;
		leftChild = null;
		rightChild = null;
	}
	
}
